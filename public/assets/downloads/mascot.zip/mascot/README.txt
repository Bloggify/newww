Usage: http://bloggify.org/logos
